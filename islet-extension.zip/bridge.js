/*
 * Islet bridge: runs in the extension's isolated world on Slack and WhatsApp Web.
 * Passes settings to hook.js and passes captured notifications to the background.
 */
(function () {
  'use strict';
  if (window.top !== window) return;
  // After Islet reloads or updates, the old copy of this script is cut off from the extension.
  // Let a fresh copy take over in that case; otherwise run only once.
  if (window.__isletBridge && window.__isletBridge.alive()) return;
  window.__isletBridge = { alive: () => { try { return !!chrome.runtime.id; } catch (_) { return false; } } };
  const gen = Date.now() + Math.random();

  const source = location.hostname === 'web.whatsapp.com' ? 'whatsapp' : 'slack';
  let enabled = false;

  function pushConfig(sources) {
    const s = (sources && sources[source]) || {};
    enabled = !!s.enabled;
    window.postMessage({ __isletHookConfig: { gen, enabled, replace: (s.mode || 'island') === 'island' } }, location.origin);
  }
  chrome.storage.local.get({ sources: null }).then(({ sources }) => pushConfig(sources)).catch(() => {});
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.sources) pushConfig(changes.sources.newValue);
  });

  // If Islet is disabled, removed or mid-update, give notifications back to the app at once,
  // so nothing is silently swallowed. A freshly attached copy (newer gen) overrides this.
  let dead = false;
  function standDown() {
    if (dead) return;
    dead = true; enabled = false;
    window.postMessage({ __isletHookConfig: { gen, enabled: false, replace: false } }, location.origin);
    window.removeEventListener('message', onHook);
    clearInterval(watch);
  }
  const watch = setInterval(() => { if (!window.__isletBridge || !chrome.runtime || !chrome.runtime.id) standDown(); }, 2000);

  // Drop exact repeats (some apps fire the same notification twice).
  const recent = new Map();
  function onHook(e) {
    if (e.source !== window || !e.data || e.data.__isletHook !== true || !enabled) return;
    if (!chrome.runtime || !chrome.runtime.id) { standDown(); return; }
    const d = e.data;
    const key = d.title + '|' + d.body;
    const now = Date.now();
    if (recent.has(key) && now - recent.get(key) < 3000) return;
    recent.set(key, now);
    if (recent.size > 40) recent.delete(recent.keys().next().value);
    try {
      chrome.runtime.sendMessage({ type: 'ISLET_WEB_NOTE', source, id: String(d.id), title: String(d.title), body: String(d.body) }).catch(() => {});
    } catch (_) { standDown(); }
  }
  window.addEventListener('message', onHook);

  // Islet's Open button: "click" the app's own notification so it jumps to that chat.
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && msg.type === 'ISLET_HOOK_CLICK' && msg.id) window.postMessage({ __isletHookClick: String(msg.id) }, location.origin);
  });

  chrome.runtime.sendMessage({ type: 'ISLET_WEB_HELLO', source }).catch(() => {});
})();
