/*
 * Islet bridge: runs in the extension's isolated world on Slack and WhatsApp Web.
 * Passes settings to hook.js and passes captured notifications to the background.
 */
(function () {
  'use strict';
  if (window.__isletBridge || window.top !== window) return;
  window.__isletBridge = true;

  const source = location.hostname === 'web.whatsapp.com' ? 'whatsapp' : 'slack';
  let enabled = false;

  function pushConfig(sources) {
    const s = (sources && sources[source]) || {};
    enabled = !!s.enabled;
    window.postMessage({ __isletHookConfig: { enabled, replace: (s.mode || 'island') === 'island' } }, location.origin);
  }
  chrome.storage.local.get({ sources: null }).then(({ sources }) => pushConfig(sources)).catch(() => {});
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.sources) pushConfig(changes.sources.newValue);
  });

  // Drop exact repeats (some apps fire the same notification twice).
  const recent = new Map();
  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data || e.data.__isletHook !== true || !enabled) return;
    const d = e.data;
    const key = d.title + '|' + d.body;
    const now = Date.now();
    if (recent.has(key) && now - recent.get(key) < 3000) return;
    recent.set(key, now);
    if (recent.size > 40) recent.delete(recent.keys().next().value);
    chrome.runtime.sendMessage({ type: 'ISLET_WEB_NOTE', source, id: String(d.id), title: String(d.title), body: String(d.body) }).catch(() => {});
  });

  // Islet's Open button: "click" the app's own notification so it jumps to that chat.
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && msg.type === 'ISLET_HOOK_CLICK' && msg.id) window.postMessage({ __isletHookClick: String(msg.id) }, location.origin);
  });

  chrome.runtime.sendMessage({ type: 'ISLET_WEB_HELLO', source }).catch(() => {});
})();
