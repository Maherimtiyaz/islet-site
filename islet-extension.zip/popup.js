/* Islet popup: compose, schedule, focus, and style with a live preview. */
'use strict';

const C = window.IsletCore;
const $ = (s) => document.querySelector(s);
const send = (msg) => chrome.runtime.sendMessage(msg);
const timeLabel = (ms) => new Date(ms).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });

const SAMPLES = {
  message: { title: 'Priya Raman', body: 'Can you review the pricing deck before 4?', app: 'slack' },
  success: { title: 'Deploy finished', body: 'islet-web is live · 2m 14s', app: 'vercel' },
  reminder: { title: 'Stand-up in 10 minutes', body: 'Grab your notes, the link is in the invite.', app: 'calendar' },
  alert: { title: 'Battery at 10%', body: 'Plug in soon. About 18 minutes left.', app: 'system' },
  timer: { title: 'Focus · 25 min', body: "Ends at 4:25 PM. I'll tap you when it's done.", app: 'focus' },
};

let settings = C.DEFAULTS;
let kind = 'message';
let previewKind = 'message';
let delay = 0;
let focusMin = 25;
let statusTimer = 0;

function status(text) {
  $('#status').textContent = text;
  clearTimeout(statusTimer);
  statusTimer = setTimeout(() => ($('#status').textContent = ''), 3000);
}

// ---------- tabs ----------
document.querySelectorAll('[role="tab"]').forEach((tab) => tab.addEventListener('click', () => {
  document.querySelectorAll('[role="tab"]').forEach((t) => {
    const on = t === tab;
    t.setAttribute('aria-selected', String(on));
    document.getElementById(t.getAttribute('aria-controls')).hidden = !on;
  });
  if (tab.id === 'tab-style') showPreview();
}));

// ---------- kind tiles (reflect the chosen icon style and colors) ----------
function kindTiles(container, current, role) {
  const acc = C.resolveAccents(settings);
  container.innerHTML = C.KINDS.map((k) => {
    const attr = role === 'radio' ? `role="radio" aria-checked="${k === current}"` : `aria-pressed="${k === current}"`;
    return `<button type="button" ${attr} data-kind="${k}" style="--c:${acc[k]}"><span class="k-ico">${C.glyph(k, settings.iconStyle)}</span>${C.LABELS[k]}</button>`;
  }).join('');
}
function paintAccent() {
  const a = C.resolveAccents(settings)[kind];
  document.documentElement.style.setProperty('--accent', a);
  document.documentElement.style.setProperty('--on-accent', C.onColor(a));
  document.documentElement.style.setProperty('--focus', C.resolveAccents(settings).timer);
}
function drawKinds() {
  kindTiles($('#kinds'), kind, 'radio');
  kindTiles($('#previewKinds'), previewKind, 'button');
  paintAccent();
}
$('#kinds').addEventListener('click', (e) => {
  const b = e.target.closest('button[data-kind]'); if (!b) return;
  kind = b.dataset.kind;
  $('#title').placeholder = SAMPLES[kind].title;
  $('#body').placeholder = SAMPLES[kind].body;
  drawKinds();
});
$('#previewKinds').addEventListener('click', (e) => {
  const b = e.target.closest('button[data-kind]'); if (!b) return;
  previewKind = b.dataset.kind;
  drawKinds();
  showPreview();
});

// ---------- send ----------
function radio(group, onPick) {
  group.addEventListener('click', (e) => {
    const btn = e.target.closest('button[role="radio"]'); if (!btn) return;
    group.querySelectorAll('button[role="radio"]').forEach((b) => b.setAttribute('aria-checked', String(b === btn)));
    onPick(btn.dataset.min);
  });
}
function sendLabel() {
  $('#send').textContent = delay === 0 ? 'Pop it now' : `Schedule for ${delay >= 60 ? delay / 60 + ' hr' : delay + ' min'}`;
}
radio($('#when'), (m) => { delay = Number(m); sendLabel(); });
radio($('#focusPick'), (m) => { focusMin = Number(m); });

$('#send').addEventListener('click', async () => {
  const payload = {
    type: kind,
    title: $('#title').value.trim() || $('#title').placeholder,
    body: $('#body').value.trim() || $('#body').placeholder,
    app: 'islet',
  };
  if (delay === 0) {
    const res = await send({ type: 'ISLET_POP', payload });
    status(res && res.via === 'system' ? 'This page blocks extensions, so it went to system notifications.' : 'Popped on this tab.');
  } else {
    const res = await send({ type: 'ISLET_SCHEDULE', minutes: delay, payload });
    status(`Scheduled for ${timeLabel(res.when)}.`);
    renderState();
  }
});

$('#focusBtn').addEventListener('click', async () => {
  const st = await send({ type: 'ISLET_STATE' });
  if (st.focus) await send({ type: 'ISLET_FOCUS_STOP' });
  else await send({ type: 'ISLET_FOCUS_START', minutes: focusMin });
  renderState();
});

// ---------- upcoming + focus ----------
let focusTick = 0;
async function renderState() {
  const st = await send({ type: 'ISLET_STATE' });
  const acc = C.resolveAccents(settings);
  const list = $('#upcoming');
  const items = Object.entries(st.scheduled || {}).sort((a, b) => a[1].when - b[1].when);
  list.hidden = items.length === 0;
  list.textContent = '';
  for (const [id, item] of items) {
    const li = document.createElement('li');
    const dot = document.createElement('i');
    dot.style.cssText = `width:6px;height:6px;border-radius:50%;flex:none;background:${acc[item.payload.type] || acc.message}`;
    const t = document.createElement('span'); t.className = 't'; t.textContent = item.payload.title;
    const time = document.createElement('time'); time.textContent = timeLabel(item.when);
    const x = document.createElement('button'); x.type = 'button'; x.textContent = '×'; x.setAttribute('aria-label', `Cancel ${item.payload.title}`);
    x.addEventListener('click', async () => { await send({ type: 'ISLET_CANCEL', id }); renderState(); });
    li.append(dot, t, time, x);
    list.appendChild(li);
  }

  clearInterval(focusTick);
  const btn = $('#focusBtn');
  if (st.focus) {
    btn.textContent = 'Stop';
    btn.classList.add('running');
    $('#focusPick').hidden = true;
    const draw = () => {
      const left = Math.max(0, st.focus.end - Date.now());
      $('#focusState').textContent = `${Math.floor(left / 60000)}:${String(Math.floor((left % 60000) / 1000)).padStart(2, '0')} left`;
    };
    draw();
    focusTick = setInterval(draw, 1000);
  } else {
    btn.textContent = 'Start';
    btn.classList.remove('running');
    $('#focusPick').hidden = false;
    $('#focusState').textContent = '';
  }
}

// ---------- style + live preview ----------
let preview = null;
function showPreview() {
  if (!preview) preview = C.create(Object.assign({}, settings, { mode: 'contained', mount: $('#preview'), top: 10 }));
  preview.setOptions(settings);
  preview.replace(Object.assign({ type: previewKind, sticky: true }, SAMPLES[previewKind]));
}

let saveTimer = 0;
const customizer = IsletCustomizer.mount($('#customizer'), settings, (next, hintKind) => {
  settings = next;
  if (hintKind && C.KINDS.includes(hintKind)) previewKind = hintKind;
  drawKinds();
  showPreview();
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => chrome.storage.sync.set({ islet: settings }), 250);
});

chrome.storage.sync.get({ islet: null }).then(({ islet }) => {
  if (islet) { settings = C.mergeOptions(C.DEFAULTS, islet); customizer.set(settings); }
  drawKinds();
});

drawKinds();
sendLabel();
renderState();

// ---------- sources: GitHub + Gmail ----------
let sources = null;
const ago = (ms) => {
  const s = Math.round((Date.now() - ms) / 1000);
  return s < 60 ? 'just now' : s < 3600 ? `${Math.round(s / 60)} min ago` : `${Math.round(s / 3600)} h ago`;
};
function pickV(group, value) {
  group.querySelectorAll('button[role="radio"]').forEach((b) => b.setAttribute('aria-checked', String(b.dataset.v === String(value))));
}
function radioV(group, onPick) {
  group.addEventListener('click', (e) => {
    const b = e.target.closest('button[role="radio"]'); if (!b) return;
    pickV(group, b.dataset.v); onPick(b.dataset.v);
  });
}
function statusText(on, st, what) {
  if (!on) return { text: 'Off', cls: '' };
  if (!st) return { text: 'Checking…', cls: '' };
  if (!st.ok) return { text: st.text || 'Something went wrong.', cls: 'err' };
  const n = st.unread || 0;
  return { text: `${n ? `${n} unread ${n === 1 ? what.replace(/s$/, '') : what}` : 'All caught up'} · checked ${ago(st.at)}`, cls: 'ok' };
}

async function renderSources() {
  const r = await send({ type: 'ISLET_SOURCES_GET' });
  sources = r.sources;
  const gh = sources.github, gm = sources.gmail;

  $('#src-github').classList.toggle('on', gh.enabled);
  $('#gh-on').setAttribute('aria-checked', String(gh.enabled));
  $('#gh-token-empty').hidden = !!r.token;
  $('#gh-token-saved').hidden = !r.token;
  $('#gh-hint').textContent = r.token;
  pickV($('#gh-filter'), gh.filter);
  const ghs = gh.enabled && !r.token ? { text: 'Add a token to start.', cls: 'err' } : statusText(gh.enabled, r.status.github, 'notifications');
  $('#gh-status').textContent = ghs.text; $('#gh-status').className = 'src-status ' + ghs.cls;

  $('#src-gmail').classList.toggle('on', gm.enabled);
  $('#gm-on').setAttribute('aria-checked', String(gm.enabled));
  $('#gm-account').value = String(gm.account);
  pickV($('#gm-label'), gm.label);
  const gms = statusText(gm.enabled, r.status.gmail, 'emails');
  $('#gm-status').textContent = gms.text; $('#gm-status').className = 'src-status ' + gms.cls;

  pickV($('#interval'), sources.interval);

  for (const k of ['slack', 'whatsapp']) {
    const c = sources[k], st = r.status[k] || {};
    $('#src-' + k).classList.toggle('on', c.enabled);
    $('#' + k + '-on').setAttribute('aria-checked', String(c.enabled));
    pickV($('#' + k + '-mode'), c.mode);
    pickV($('#' + k + '-preview'), c.preview);
    let text = 'Off', cls = '';
    if (c.enabled && !st.tabs) { text = `Open ${k === 'slack' ? 'Slack' : 'WhatsApp Web'} in a tab to start.`; cls = 'err'; }
    else if (c.enabled) { text = `Watching ${st.tabs} tab${st.tabs > 1 ? 's' : ''}${st.lastAt ? ' · last message ' + ago(st.lastAt) : ''}`; cls = 'ok'; }
    $('#' + k + '-status').textContent = text; $('#' + k + '-status').className = 'src-status ' + cls;
  }
}
async function saveSources() {
  await send({ type: 'ISLET_SOURCES_SET', sources });
  renderSources();
}

$('#gh-on').addEventListener('click', () => { sources.github.enabled = !sources.github.enabled; saveSources(); });
$('#gm-on').addEventListener('click', () => { sources.gmail.enabled = !sources.gmail.enabled; saveSources(); });
radioV($('#gh-filter'), (v) => { sources.github.filter = v; saveSources(); });
radioV($('#gm-label'), (v) => { sources.gmail.label = v; saveSources(); });
radioV($('#interval'), (v) => { sources.interval = Number(v); saveSources(); });
$('#gm-account').addEventListener('change', (e) => { sources.gmail.account = Number(e.target.value); saveSources(); });

$('#gh-save').addEventListener('click', async () => {
  const res = await send({ type: 'ISLET_GH_TOKEN_SET', token: $('#gh-token').value });
  if (res && res.error) { status(res.error); return; }
  $('#gh-token').value = '';
  status('Token saved.');
  renderSources();
});
$('#gh-token').addEventListener('keydown', (e) => { if (e.key === 'Enter') $('#gh-save').click(); });
$('#gh-remove').addEventListener('click', async () => { await send({ type: 'ISLET_GH_TOKEN_CLEAR' }); status('Token removed.'); renderSources(); });
$('#gh-check').addEventListener('click', async () => { status('Checking GitHub…'); await send({ type: 'ISLET_CHECK_NOW', source: 'github' }); status(''); renderSources(); });
$('#gm-check').addEventListener('click', async () => { status('Checking Gmail…'); await send({ type: 'ISLET_CHECK_NOW', source: 'gmail' }); status(''); renderSources(); });

for (const k of ['slack', 'whatsapp']) {
  $('#' + k + '-on').addEventListener('click', () => { sources[k].enabled = !sources[k].enabled; saveSources(); });
  radioV($('#' + k + '-mode'), (v) => { sources[k].mode = v; saveSources(); });
  radioV($('#' + k + '-preview'), (v) => { sources[k].preview = v; saveSources(); });
  $('#' + k + '-open').addEventListener('click', () => send({ type: 'ISLET_OPEN_WEB', source: k }));
}

$('#tab-sources').addEventListener('click', renderSources);
renderSources();
