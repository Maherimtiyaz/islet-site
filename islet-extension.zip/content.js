/* Islet content script: mounts the island in the page on first use and listens for notes. */
(function () {
  'use strict';
  if (window.top !== window) return;
  // After Islet reloads or updates, the old copy is cut off; let a fresh copy take over.
  if (window.__isletContent && window.__isletContent.alive()) return;
  window.__isletContent = { alive: () => { try { return !!chrome.runtime.id; } catch (_) { return false; } } };
  document.querySelectorAll('islet-root').forEach((el) => el.remove()); // an old island, if any

  let settings = window.IsletCore.DEFAULTS;
  let island = null;

  chrome.storage.sync.get({ islet: null }).then(({ islet }) => {
    if (islet) settings = islet;
    if (island) island.setOptions(settings);
  }).catch(() => {});

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'sync' && changes.islet) {
      settings = changes.islet.newValue || window.IsletCore.DEFAULTS;
      if (island) island.setOptions(settings);
    }
  });

  // In fullscreen (a YouTube video, a slideshow), only the fullscreen element is drawn,
  // so the island moves inside it and back out afterwards.
  function placeIsland() {
    if (!island) return;
    const fs = document.fullscreenElement;
    const target = fs && !/^(VIDEO|IFRAME|IMG|CANVAS)$/.test(fs.tagName) ? fs : document.documentElement;
    if (island.host.parentNode !== target) target.appendChild(island.host);
  }
  document.addEventListener('fullscreenchange', placeIsland);

  function getIsland() {
    // Some sites rebuild their whole page; mount a fresh island if ours was removed.
    if (island && !island.connected) { try { island.destroy(); } catch (_) {} island = null; }
    if (!island) {
      island = window.IsletCore.create(Object.assign({}, settings, {
        mode: 'fixed',
        onAction(id, note) {
          chrome.runtime.sendMessage({ type: 'ISLET_ACTION', id, note }).catch(() => {});
        },
      }));
    }
    placeIsland();
    return island;
  }

  chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
    if (msg && msg.type === 'ISLET_SHOW') {
      getIsland().show(msg.payload);
      reply({ ok: true });
    }
  });

  // Screen sharing started or stopped in this tab (from share-hook.js).
  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data || e.data.__isletShare !== true) return;
    try { chrome.runtime.sendMessage({ type: 'ISLET_SHARE', id: String(e.data.id).slice(0, 60), active: !!e.data.active }).catch(() => {}); } catch (_) {}
  });

  // Page API: any page can pop an island in its own tab.
  // window.postMessage({ __islet: true, type: 'success', title: 'Build passed', body: 'main · 2m 14s' }, '*')
  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data || e.data.__islet !== true) return;
    const d = e.data;
    getIsland().show({
      type: typeof d.type === 'string' ? d.type : 'message',
      title: typeof d.title === 'string' ? d.title : '',
      body: typeof d.body === 'string' ? d.body : '',
      url: typeof d.url === 'string' ? d.url : '',
      app: typeof d.app === 'string' ? d.app : location.hostname.replace(/^www\./, ''),
      duration: typeof d.duration === 'number' ? Math.min(Math.max(d.duration, 1500), 60000) : undefined,
    });
  });
})();
