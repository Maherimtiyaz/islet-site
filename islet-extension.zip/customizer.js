/*
 * Islet style panel. Used by the extension popup and the demo page.
 *   IsletCustomizer.mount(container, settings, onChange(nextSettings, kindToPreview))
 * Looks (presets) first; every individual option sits under "Fine-tune".
 * Colors come from the host page through --cz-* custom properties.
 */
(function (global) {
  'use strict';
  if (global.IsletCustomizer) return;
  const C = global.IsletCore;

  const CSS = `
.cz { display: grid; gap: 16px; color: var(--cz-fg); font-size: 13px; }
.cz-h { margin: 0; font-size: 10.5px; font-weight: 650; letter-spacing: .1em; text-transform: uppercase; color: var(--cz-sub); }
.cz-looks { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 8px; }
.cz-look { all: unset; box-sizing: border-box; cursor: pointer; display: grid; gap: 7px; padding: 6px 6px 8px; border-radius: 12px; background: var(--cz-chip);
  border: 1px solid transparent; font-size: 12px; font-weight: 600; color: var(--cz-sub); text-align: center; transition: color .15s, border-color .15s; }
.cz-look:hover { color: var(--cz-fg); }
.cz-look[aria-pressed="true"] { border-color: var(--cz-fg); color: var(--cz-fg); }
.cz-pv { height: 30px; border-radius: 15px; display: flex; align-items: center; gap: 6px; padding: 0 9px; box-sizing: border-box; min-width: 0; }
.cz-pv .d { width: 6px; height: 6px; border-radius: 50%; flex: none; }
.cz-pv .tg { flex: none; font: 700 7.5px/1 ui-monospace, Menlo, Consolas, monospace; letter-spacing: .05em; padding: 3px 4px; border-radius: 2px; }
.cz-pv .ic { width: 15px; height: 15px; border-radius: 50%; flex: none; }
.cz-pv .ln { display: grid; gap: 3px; flex: 1; min-width: 0; }
.cz-pv .ln i { display: block; height: 3px; border-radius: 2px; opacity: .9; }
.cz-pv .ln i + i { width: 70%; opacity: .45; }

.cz-more { border-top: 1px solid color-mix(in srgb, var(--cz-sub) 25%, transparent); padding-top: 12px; }
.cz-more > summary { list-style: none; cursor: pointer; display: flex; align-items: center; justify-content: space-between; font-size: 12.5px; font-weight: 600; color: var(--cz-sub); }
.cz-more > summary::-webkit-details-marker { display: none; }
.cz-more > summary::after { content: ""; width: 7px; height: 7px; border-right: 1.5px solid currentColor; border-bottom: 1.5px solid currentColor; transform: rotate(45deg); transition: transform .2s; margin-right: 4px; }
.cz-more[open] > summary::after { transform: rotate(-135deg); }
.cz-more > summary:hover { color: var(--cz-fg); }
.cz-body { display: grid; gap: 16px; padding-top: 14px; }
.cz-sec { display: grid; gap: 9px; }

.cz-row { display: grid; grid-template-columns: 70px minmax(0, 1fr); align-items: center; gap: 10px; }
.cz-row > span { color: var(--cz-sub); font-size: 12.5px; }
.cz-seg { display: flex; gap: 2px; padding: 2px; border-radius: 10px; background: var(--cz-chip); min-width: 0; }
.cz-seg button { all: unset; flex: 1; min-width: 0; box-sizing: border-box; cursor: pointer; text-align: center;
  padding: 6px 2px; border-radius: 8px; font-size: 12px; font-weight: 600; color: var(--cz-sub); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; transition: background .15s, color .15s; }
.cz-seg button:hover { color: var(--cz-fg); }
.cz-seg button[aria-pressed="true"] { background: var(--cz-sel); color: var(--cz-fg); box-shadow: 0 1px 2px rgba(0,0,0,.12); }
.cz button:focus-visible, .cz summary:focus-visible, .cz label:focus-within { outline: 2px solid var(--cz-focus); outline-offset: 2px; }

.cz-sws { display: flex; gap: 7px; flex-wrap: wrap; align-items: center; }
.cz-sw { all: unset; box-sizing: border-box; cursor: pointer; width: 24px; height: 24px; border-radius: 50%; position: relative;
  box-shadow: inset 0 0 0 1px rgba(127,127,140,.35); transition: transform .12s; }
.cz-sw:hover { transform: scale(1.08); }
.cz-sw[aria-pressed="true"]::after { content: ""; position: absolute; inset: -4px; border-radius: 50%; border: 2px solid var(--cz-fg); }
.cz-pick { position: relative; width: 24px; height: 24px; border-radius: 50%; cursor: pointer; overflow: hidden; flex: none;
  background: conic-gradient(#FF6B6B, #FFD166, #4FE0A2, #6CC4FF, #9C8CFF, #FF6B6B); box-shadow: inset 0 0 0 1px rgba(127,127,140,.35); }
.cz-pick.on::after { content: ""; position: absolute; inset: 0; border-radius: 50%; box-shadow: inset 0 0 0 2px var(--cz-fg), inset 0 0 0 4px var(--cz-chip); }
.cz-pick input, .cz-acc input { position: absolute; inset: 0; width: 100%; height: 100%; opacity: 0; cursor: pointer; border: 0; padding: 0; }
.cz-pals { display: flex; gap: 6px; flex-wrap: wrap; }
.cz-pal { all: unset; box-sizing: border-box; cursor: pointer; display: flex; align-items: center; gap: 6px; padding: 5px 9px 5px 7px; border-radius: 999px;
  background: var(--cz-chip); font-size: 11.5px; font-weight: 600; color: var(--cz-sub); border: 1px solid transparent; }
.cz-pal:hover { color: var(--cz-fg); }
.cz-pal[aria-pressed="true"] { border-color: var(--cz-fg); color: var(--cz-fg); }
.cz-dots { display: flex; }
.cz-dots i { width: 8px; height: 8px; border-radius: 50%; margin-left: -2px; box-shadow: 0 0 0 1.5px var(--cz-chip); }
.cz-accs { display: grid; grid-template-columns: repeat(5, minmax(0, 1fr)); gap: 6px; }
.cz-acc { position: relative; display: grid; justify-items: center; gap: 4px; font-size: 10.5px; color: var(--cz-sub); cursor: pointer; border-radius: 8px; padding: 2px 0; }
.cz-acc i { width: 20px; height: 20px; border-radius: 50%; background: var(--c); box-shadow: inset 0 0 0 1px rgba(0,0,0,.12); transition: transform .12s; }
.cz-acc:hover i { transform: scale(1.1); }
.cz-toggles { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 6px; }
.cz-tg { all: unset; box-sizing: border-box; cursor: pointer; display: flex; align-items: center; gap: 8px; padding: 7px 9px; border-radius: 10px; white-space: nowrap;
  background: var(--cz-chip); font-size: 12px; font-weight: 600; color: var(--cz-sub); }
.cz-tg::before { content: ""; width: 22px; height: 13px; border-radius: 999px; background: color-mix(in srgb, var(--cz-sub) 40%, transparent); flex: none;
  background-image: radial-gradient(circle at 6.5px 50%, #fff 4.5px, transparent 5px); transition: background-color .15s, background-position .15s; }
.cz-tg[aria-pressed="true"] { color: var(--cz-fg); }
.cz-tg[aria-pressed="true"]::before { background-color: var(--cz-on); background-position: 9px 0; }
.cz-reset { all: unset; cursor: pointer; justify-self: start; font-size: 12px; font-weight: 600; color: var(--cz-sub); }
.cz-reset:hover { color: var(--cz-fg); }
`;

  function injectCSS() {
    if (document.getElementById('islet-cz-css')) return;
    const s = document.createElement('style');
    s.id = 'islet-cz-css'; s.textContent = CSS;
    document.head.appendChild(s);
  }

  const SURF_SWATCH = {
    ink: '#0A0A0C', graphite: '#2A2B31', midnight: '#101A35', terminal: '#070A08', editor: '#1E222A', frost: '#F4F4F7',
    aurora: 'radial-gradient(120% 140% at 0% 0%, #7A62E0, #0E0C1F 70%)',
  };
  const SURF_NAMES = { ink: 'Ink', graphite: 'Graphite', midnight: 'Midnight', terminal: 'Terminal', editor: 'Editor', frost: 'Frost', aurora: 'Aurora' };
  const PAL_NAMES = { classic: 'Classic', pastel: 'Pastel', neon: 'Neon', ocean: 'Ocean', terminal: 'Terminal', editor: 'Editor', mono: 'Mono' };
  const KIND_SHORT = { message: 'Message', success: 'Done', reminder: 'Remind', alert: 'Alert', timer: 'Focus' };

  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const seg = (key, opts, cur) => `<div class="cz-seg" role="group">${opts.map(([v, label]) =>
    `<button type="button" data-k="${key}" data-v="${v}" aria-pressed="${String(cur) === String(v)}">${label}</button>`).join('')}</div>`;
  const row = (label, control) => `<div class="cz-row"><span>${label}</span>${control}</div>`;

  // A tiny static drawing of each look, for the Looks grid.
  function lookPreview(id) {
    const p = C.PRESETS[id];
    const s = C.surfaceOf(p.surface);
    const acc = C.resolveAccents(p).success;
    const bg = p.surface === 'aurora' ? `radial-gradient(130% 170% at 0% 0%, color-mix(in srgb, ${acc} 40%, #0E0C1F), #0E0C1F 62%)` : s.solid;
    const r = p.shape === 'sharp' ? '4px' : p.shape === 'soft' ? '9px' : '15px';
    let icon;
    if (p.iconStyle === 'dot') icon = `<span class="d" style="background:${acc}"></span>`;
    else if (p.iconStyle === 'tag') icon = `<span class="tg" style="color:${acc};box-shadow:inset 0 0 0 1px ${acc}66">OK</span>`;
    else icon = `<span class="ic" style="background:${p.iconStyle === 'solid' ? acc : acc + '33'};border-radius:${p.iconShape === 'squircle' ? '30%' : '50%'}"></span>`;
    const lines = p.lines === 'one' ? `<i style="background:${s.fg}"></i>` : `<i style="background:${s.fg}"></i><i style="background:${s.fg}"></i>`;
    const edge = p.surface === 'frost' ? 'box-shadow:inset 0 0 0 1px rgba(0,0,0,.1);' : '';
    return `<span class="cz-pv" style="background:${bg};border-radius:${r};${edge}">${icon}<span class="ln">${lines}</span></span>`;
  }

  function render(s, moreOpen) {
    const acc = C.resolveAccents(s);
    const customSurface = !SURF_SWATCH[s.surface];
    return `
<div class="cz">
  <section class="cz-sec">
    <h3 class="cz-h">Look</h3>
    <div class="cz-looks">${Object.keys(C.PRESETS).map((id) =>
      `<button type="button" class="cz-look" data-k="preset" data-v="${id}" aria-pressed="${s.preset === id}">${lookPreview(id)}${C.PRESET_NAMES[id]}</button>`).join('')}</div>
  </section>

  <details class="cz-more"${moreOpen ? ' open' : ''}>
    <summary>Fine-tune${s.preset === 'custom' ? ' · edited' : ''}</summary>
    <div class="cz-body">
      <section class="cz-sec">
        <h3 class="cz-h">Colors</h3>
        ${row('Island', `<div class="cz-sws">${Object.keys(SURF_SWATCH).map((k) =>
          `<button type="button" class="cz-sw" data-k="surface" data-v="${k}" title="${SURF_NAMES[k]}" aria-label="${SURF_NAMES[k]}" aria-pressed="${s.surface === k}" style="background:${SURF_SWATCH[k]}"></button>`).join('')}
          <label class="cz-pick${customSurface ? ' on' : ''}" title="Custom color"><input type="color" data-k="surfaceCustom" value="${customSurface ? esc(s.surface) : '#1E1F24'}" aria-label="Custom island color"></label></div>`)}
        <div class="cz-pals">${Object.keys(PAL_NAMES).map((p) => {
          const cols = p === 'mono' ? C.KINDS.map(() => C.surfaceOf(s.surface).fg) : C.KINDS.map((k) => C.PALETTES[p][k]);
          return `<button type="button" class="cz-pal" data-k="palette" data-v="${p}" aria-pressed="${s.palette === p}"><span class="cz-dots">${cols.map((c) => `<i style="background:${c}"></i>`).join('')}</span>${PAL_NAMES[p]}</button>`;
        }).join('')}</div>
        <div class="cz-accs">${C.KINDS.map((k) =>
          `<label class="cz-acc" style="--c:${acc[k]}" title="${C.LABELS[k]} color"><i></i>${KIND_SHORT[k]}<input type="color" data-k="accent" data-kind="${k}" value="${/^#[0-9a-f]{6}$/i.test(acc[k]) ? acc[k] : '#888888'}" aria-label="${C.LABELS[k]} color"></label>`).join('')}</div>
      </section>

      <section class="cz-sec">
        <h3 class="cz-h">Icon</h3>
        ${row('Style', seg('iconStyle', [['dot', 'Dot'], ['line', 'Line'], ['solid', 'Solid'], ['tag', 'Tag'], ['emoji', 'Emoji']], s.iconStyle))}
        ${row('Badge', seg('iconShape', [['none', 'None'], ['circle', 'Circle'], ['squircle', 'Rounded']], s.iconShape))}
      </section>

      <section class="cz-sec">
        <h3 class="cz-h">Island</h3>
        ${row('Shape', seg('shape', [['pill', 'Pill'], ['soft', 'Soft'], ['sharp', 'Sharp']], s.shape))}
        ${row('Text', seg('lines', [['one', 'One line'], ['two', 'Two lines']], s.lines))}
        ${row('Font', seg('font', [['system', 'Sans'], ['mono', 'Mono']], s.font))}
        ${row('Size', seg('size', [['compact', 'Compact'], ['regular', 'Regular']], s.size))}
        ${row('Position', seg('position', [['center', 'Center'], ['right', 'Right']], s.position))}
        ${row('Countdown', seg('countdown', [['off', 'Off'], ['bar', 'Bar'], ['ring', 'Ring']], s.countdown))}
      </section>

      <section class="cz-sec">
        <h3 class="cz-h">Motion and sound</h3>
        <div class="cz-toggles">
          <button type="button" class="cz-tg" data-k="effect" data-v="edge" aria-pressed="${!!s.effects.edge}">Glow</button>
          <button type="button" class="cz-tg" data-k="effect" data-v="ripple" aria-pressed="${!!s.effects.ripple}">Ripple</button>
          <button type="button" class="cz-tg" data-k="effect" data-v="sparks" aria-pressed="${!!s.effects.sparks}">Sparks</button>
          <button type="button" class="cz-tg" data-k="effect" data-v="type" aria-pressed="${!!s.effects.type}">Typing</button>
        </div>
        ${row('Sound', seg('tone', [['off', 'Off'], ['pop', 'Pop'], ['blip', 'Blip'], ['chime', 'Chime']], s.tone))}
        ${row('Stays for', seg('duration', [[3000, '3 s'], [5000, '5 s'], [8000, '8 s']], s.duration))}
      </section>

      <button type="button" class="cz-reset" data-k="reset">Reset to default</button>
    </div>
  </details>
</div>`;
  }

  function mount(el, settings, onChange) {
    injectCSS();
    let s = C.mergeOptions(C.DEFAULTS, settings);
    let moreOpen = false;
    const draw = () => { el.innerHTML = render(s, moreOpen); };
    const emit = (kind) => onChange(JSON.parse(JSON.stringify(s)), kind);
    const commit = (next, kind) => { s = C.mergeOptions(C.DEFAULTS, next); draw(); emit(kind); };

    el.addEventListener('toggle', (e) => { if (e.target.classList && e.target.classList.contains('cz-more')) moreOpen = e.target.open; }, true);

    el.addEventListener('click', (e) => {
      const b = e.target.closest('button[data-k]');
      if (!b) return;
      const k = b.dataset.k, v = b.dataset.v;
      if (k === 'reset') return commit(C.DEFAULTS);
      if (k === 'preset') return commit(C.applyPreset(s, v), 'success');
      const next = JSON.parse(JSON.stringify(s));
      next.preset = 'custom';
      if (k === 'effect') { next.effects[v] = !next.effects[v]; return commit(next, v === 'sparks' ? 'success' : null); }
      if (k === 'palette') { next.palette = v; next.accents = null; return commit(next); }
      if (k === 'duration') next.duration = Number(v); else next[k] = v;
      commit(next, k === 'tone' ? 'success' : null);
    });

    // Color inputs: update live while dragging, redraw the panel when done.
    let liveTimer = 0;
    const colorChange = (e, final) => {
      const inp = e.target;
      if (inp.tagName !== 'INPUT' || inp.type !== 'color') return;
      const next = JSON.parse(JSON.stringify(s));
      next.preset = 'custom';
      let kind = null;
      if (inp.dataset.k === 'surfaceCustom') next.surface = inp.value;
      if (inp.dataset.k === 'accent') {
        next.accents = Object.assign(C.resolveAccents(s), { [inp.dataset.kind]: inp.value });
        next.palette = 'custom';
        kind = inp.dataset.kind;
        const lab = inp.closest('.cz-acc'); if (lab) lab.style.setProperty('--c', inp.value);
      }
      s = C.mergeOptions(C.DEFAULTS, next);
      clearTimeout(liveTimer);
      if (final) { draw(); emit(kind); }
      else liveTimer = setTimeout(() => emit(kind), 30);
    };
    el.addEventListener('input', (e) => colorChange(e, false));
    el.addEventListener('change', (e) => colorChange(e, true));

    draw();
    return { set(next) { s = C.mergeOptions(C.DEFAULTS, next); draw(); } };
  }

  global.IsletCustomizer = { mount };
})(typeof window !== 'undefined' ? window : globalThis);
