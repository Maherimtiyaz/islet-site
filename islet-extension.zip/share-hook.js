/*
 * Islet screen-share watcher: runs in every page (MAIN world, document_start).
 * When the page starts sharing your screen or a tab (Google Meet, Zoom or Teams on the web,
 * Slack huddles…), it tells Islet, so message text is hidden until the sharing stops.
 * It only notices that sharing started and stopped; it never sees what is shared.
 */
(function () {
  'use strict';
  if (window.__isletShareHook) return;
  window.__isletShareHook = true;

  const proto = window.MediaDevices && window.MediaDevices.prototype;
  if (!proto || typeof proto.getDisplayMedia !== 'function') return;

  const original = proto.getDisplayMedia;
  let seq = 0;
  const post = (id, active) => { try { window.postMessage({ __isletShare: true, id, active }, '*'); } catch (_) {} };

  proto.getDisplayMedia = function () {
    const result = original.apply(this, arguments);
    Promise.resolve(result).then((stream) => {
      try {
        const id = 'share-' + (++seq) + '-' + Date.now();
        let over = false;
        const check = () => {
          if (over) return;
          if (stream.getVideoTracks().every((t) => t.readyState === 'ended')) { over = true; post(id, false); }
        };
        post(id, true);
        stream.getTracks().forEach((t) => {
          t.addEventListener('ended', check); // stopped from Chrome's "Stop sharing" bar
          const stop = t.stop;               // stopped by the page itself (no 'ended' event then)
          t.stop = function () { const r = stop.apply(this, arguments); setTimeout(check, 0); return r; };
        });
        if (stream.addEventListener) stream.addEventListener('inactive', check);
      } catch (_) { /* never get in the page's way */ }
    }, () => {});
    return result;
  };
})();
