/*
 * Islet hook: runs inside the Slack and WhatsApp Web pages (MAIN world, document_start).
 * It wraps the browser's Notification API so every notification the app shows is also
 * handed to Islet. In "island only" mode the system notification is skipped, and the app
 * is told notifications are allowed, so it keeps sending them without the browser prompt.
 */
(function () {
  'use strict';
  if (window.__isletHook) return;
  window.__isletHook = true;

  const source = location.hostname === 'web.whatsapp.com' ? 'whatsapp' : 'slack';
  let cfg = { enabled: false, replace: false };
  const live = new Map(); // id -> notification object, so Islet's Open can "click" it
  let seq = 0;

  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data) return;
    if (e.data.__isletHookConfig) cfg = Object.assign({}, cfg, e.data.__isletHookConfig);
    if (e.data.__isletHookClick) {
      const n = live.get(e.data.__isletHookClick);
      if (!n) return;
      try {
        const ev = new Event('click');
        // A real Notification runs its onclick from dispatchEvent; our stand-in needs it called directly.
        n.dispatchEvent(ev);
        if (!(Native && n instanceof Native) && typeof n.onclick === 'function') n.onclick(ev);
      } catch (_) {}
    }
  });

  const island = () => cfg.enabled && cfg.replace;

  function forward(title, opts, obj) {
    const id = source + '-' + (++seq);
    live.set(id, obj);
    if (live.size > 50) live.delete(live.keys().next().value);
    try {
      window.postMessage({
        __isletHook: true, id, source,
        title: String(title || '').slice(0, 200),
        body: String((opts && opts.body) || '').slice(0, 600),
        tag: String((opts && opts.tag) || '').slice(0, 100),
      }, location.origin);
    } catch (_) {}
  }

  const Native = window.Notification;
  if (Native) {
    function stub(title, opts) {
      const s = new EventTarget();
      Object.assign(s, {
        title: String(title || ''), body: (opts && opts.body) || '', tag: (opts && opts.tag) || '', data: opts && opts.data,
        icon: (opts && opts.icon) || '', onclick: null, onshow: null, onclose: null, onerror: null,
        close() { try { const ev = new Event('close'); s.dispatchEvent(ev); if (typeof s.onclose === 'function') s.onclose(ev); } catch (_) {} },
      });
      return s;
    }
    const IsletNotification = function Notification(title, opts) {
      if (!new.target) throw new TypeError("Failed to construct 'Notification': Please use the 'new' operator.");
      if (island()) {
        const s = stub(title, opts);
        forward(title, opts, s);
        return s;
      }
      const n = new Native(title, opts);
      forward(title, opts, n);
      return n;
    };
    IsletNotification.prototype = Native.prototype;
    Object.defineProperty(IsletNotification, 'permission', {
      get() { return island() ? 'granted' : Native.permission; },
    });
    IsletNotification.requestPermission = function (cb) {
      if (island()) { if (typeof cb === 'function') cb('granted'); return Promise.resolve('granted'); }
      return Native.requestPermission(cb);
    };
    if ('maxActions' in Native) Object.defineProperty(IsletNotification, 'maxActions', { get() { return Native.maxActions; } });
    window.Notification = IsletNotification;
  }

  // Some apps show notifications through their service worker registration instead.
  const SWR = window.ServiceWorkerRegistration;
  if (SWR && SWR.prototype && SWR.prototype.showNotification) {
    const orig = SWR.prototype.showNotification;
    SWR.prototype.showNotification = function (title, opts) {
      forward(title, opts, null);
      if (island()) return Promise.resolve();
      return orig.call(this, title, opts);
    };
  }
})();
