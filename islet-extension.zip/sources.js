/*
 * Islet sources: GitHub notifications and unread Gmail, checked in the background.
 *
 * GitHub: REST API /notifications with a classic personal access token (notifications scope).
 *         The token lives in chrome.storage.local and is only sent to api.github.com.
 * Gmail:  the inbox Atom feed of the account already signed in to Chrome. No token, no setup.
 *
 * The first check after turning a source on only counts what's already unread,
 * so you get one summary instead of a flood. After that, each new item is an island.
 */
(function (g) {
  'use strict';

  const GH_API = 'https://api.github.com';
  const DEFAULT_SOURCES = {
    interval: 1,                                   // minutes between checks
    github: { enabled: false, filter: 'all' },     // all | important
    gmail: { enabled: false, account: 0, label: 'inbox' }, // inbox | important
    slack: { enabled: false, mode: 'island', preview: 'show' },    // mode: island | both; preview: show | hide
    whatsapp: { enabled: false, mode: 'island', preview: 'show' },
  };
  const WEB = {
    slack: { name: 'Slack', url: 'https://app.slack.com/*', home: 'https://app.slack.com/client', icon: 'slack' },
    whatsapp: { name: 'WhatsApp', url: 'https://web.whatsapp.com/*', home: 'https://web.whatsapp.com/', icon: 'chat' },
  };
  const MAX_BURST = 3;

  // reason -> [island kind, label]
  const REASONS = {
    review_requested: ['reminder', 'Review requested'],
    approval_requested: ['reminder', 'Approval requested'],
    assign: ['reminder', 'Assigned to you'],
    mention: ['message', 'Mentioned you'],
    team_mention: ['message', 'Mentioned your team'],
    author: ['message', 'New activity'],
    comment: ['message', 'New comment'],
    state_change: ['message', 'State changed'],
    subscribed: ['message', 'Watching'],
    manual: ['message', 'Subscribed'],
    invitation: ['message', 'Invitation'],
    security_alert: ['alert', 'Security alert'],
    ci_activity: ['success', 'CI'],
  };
  const IMPORTANT = new Set(['review_requested', 'approval_requested', 'assign', 'mention', 'team_mention', 'security_alert', 'ci_activity']);

  // ---------- GitHub ----------
  function ghHtmlUrl(n) {
    const repo = (n.repository && n.repository.html_url) || 'https://github.com/notifications';
    const api = n.subject && n.subject.url;
    const type = n.subject && n.subject.type;
    if (type === 'CheckSuite' || type === 'WorkflowRun') return repo + '/actions';
    if (type === 'Discussion') return repo + '/discussions';
    if (!api) return repo;
    if (/\/releases\/\d+$/.test(api)) return repo + '/releases';
    return api
      .replace(`${GH_API}/repos/`, 'https://github.com/')
      .replace(/\/pulls\/(\d+)$/, '/pull/$1')
      .replace(/\/commits\/([0-9a-f]+)$/, '/commit/$1');
  }

  function ghToNote(n) {
    let [type, label] = REASONS[n.reason] || ['message', 'New activity'];
    if (n.reason === 'ci_activity') {
      const failed = /fail|error|cancel|timed out/i.test(n.subject.title || '');
      type = failed ? 'alert' : 'success';
      label = failed ? 'CI failed' : 'CI passed';
    }
    const num = ((n.subject && n.subject.url) || '').match(/\/(?:issues|pulls)\/(\d+)$/);
    return {
      type,
      title: (n.subject && n.subject.title) || 'GitHub notification',
      body: `${label} · ${n.repository ? n.repository.full_name : 'GitHub'}${num ? '#' + num[1] : ''}`,
      app: 'github',
      icon: 'github',
      url: ghHtmlUrl(n),
      ref: 'gh:' + n.id,
      actions: [{ id: 'open', label: 'Open', primary: true }, { id: 'markread', label: 'Mark read' }],
    };
  }

  // ---------- Gmail ----------
  function decode(s) {
    return String(s || '')
      .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
      .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'")
      .replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(Number(d)))
      .replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCodePoint(parseInt(h, 16)))
      .replace(/&amp;/g, '&')
      .trim();
  }
  function tag(xml, name) {
    const m = String(xml).match(new RegExp(`<${name}(?:\\s[^>]*)?>([\\s\\S]*?)</${name}>`));
    return m ? decode(m[1]) : '';
  }
  // Service workers have no DOMParser, so read the few fields we need directly.
  function parseAtom(xml) {
    if (!/<feed[\s>]/.test(xml || '')) return null;
    const entries = [...xml.matchAll(/<entry>([\s\S]*?)<\/entry>/g)].map((m) => {
      const e = m[1];
      const author = (e.match(/<author>([\s\S]*?)<\/author>/) || [, ''])[1];
      const link = (e.match(/<link[^>]*href="([^"]*)"/) || [, ''])[1];
      return {
        id: tag(e, 'id'), title: tag(e, 'title'), summary: tag(e, 'summary'),
        name: tag(author, 'name'), email: tag(author, 'email'),
        link: decode(link), issued: tag(e, 'issued') || tag(e, 'modified'),
      };
    });
    const full = Number(tag(xml, 'fullcount'));
    return { count: Number.isFinite(full) && full > 0 ? full : entries.length, entries };
  }

  function gmailToNote(e, account) {
    const subject = e.title || '(no subject)';
    return {
      type: 'message',
      title: e.name || e.email || 'New email',
      body: e.summary ? `${subject}\n${e.summary}` : subject,
      app: 'gmail',
      icon: 'mail',
      url: /^https:\/\//.test(e.link) ? e.link : `https://mail.google.com/mail/u/${account}/`,
      actions: [{ id: 'open', label: 'Open', primary: true }, { id: 'dismiss', label: 'Dismiss' }],
    };
  }

  // ---------- storage helpers ----------
  async function loadSources() {
    const { sources } = await chrome.storage.local.get({ sources: null });
    const s = sources || {};
    return {
      interval: s.interval || DEFAULT_SOURCES.interval,
      github: Object.assign({}, DEFAULT_SOURCES.github, s.github),
      gmail: Object.assign({}, DEFAULT_SOURCES.gmail, s.gmail),
      slack: Object.assign({}, DEFAULT_SOURCES.slack, s.slack),
      whatsapp: Object.assign({}, DEFAULT_SOURCES.whatsapp, s.whatsapp),
    };
  }
  // One key per source, so GitHub and Gmail checks running at once can't overwrite each other.
  async function setStatus(src, patch) {
    const key = 'status_' + src;
    const prev = (await chrome.storage.local.get({ [key]: {} }))[key];
    await chrome.storage.local.set({ [key]: Object.assign({}, prev, patch, { at: Date.now() }) });
  }
  async function getStatus() {
    const r = await chrome.storage.local.get({ status_github: null, status_gmail: null, status_slack: null, status_whatsapp: null });
    const out = { github: r.status_github, gmail: r.status_gmail };
    for (const k of Object.keys(WEB)) {
      let tabs = 0;
      try { tabs = (await chrome.tabs.query({ url: WEB[k].url })).length; } catch (_) {}
      out[k] = Object.assign({}, r['status_' + k], { tabs });
    }
    return out;
  }

  // ---------- Slack + WhatsApp Web (captured from their open tabs) ----------
  function webToNote(source, msg, tabId, cfg) {
    const w = WEB[source];
    let title = msg.title || w.name;
    let body = msg.body || '';
    if (cfg.preview === 'hide') body = source === 'whatsapp' ? 'New message' : 'New message in Slack';
    // Slack often titles notifications "New message from X"; keep it short.
    title = title.replace(/^New message from\s+/i, '');
    return {
      type: /mentioned you|@channel|@here/i.test(msg.body || '') ? 'reminder' : 'message',
      title, body, app: source === 'whatsapp' ? 'whatsapp' : 'slack', icon: w.icon,
      ref: `web:${tabId}:${msg.id}`,
      actions: [{ id: 'focus', label: 'Open', primary: true }, { id: 'dismiss', label: 'Dismiss' }],
    };
  }

  async function announce(notes, deliver, more) {
    if (!notes.length) return;
    const shown = notes.slice(0, MAX_BURST);
    for (const n of shown) await deliver(n);
    const rest = notes.length - shown.length;
    if (rest > 0) await deliver(Object.assign({ type: 'message', title: `${rest} more`, actions: [{ id: 'open', label: 'Open', primary: true }] }, more(rest)));
  }

  // ---------- checks ----------
  async function pollGitHub(deliver, opts) {
    opts = opts || {};
    const cfg = (await loadSources()).github;
    if (!cfg.enabled && !opts.force) return;
    const st = await chrome.storage.local.get({ ghToken: '', ghSeen: null, ghLastModified: '' });
    if (!st.ghToken) return setStatus('github', { ok: false, text: 'Add a token to start.' });

    const headers = { Authorization: 'Bearer ' + st.ghToken, Accept: 'application/vnd.github+json', 'X-GitHub-Api-Version': '2022-11-28' };
    if (st.ghSeen && st.ghLastModified) headers['If-Modified-Since'] = st.ghLastModified;

    let res;
    try { res = await fetch(GH_API + '/notifications?per_page=50', { headers, cache: 'no-store' }); }
    catch (_) { return setStatus('github', { ok: false, text: "Couldn't reach GitHub. Islet will try again." }); }

    if (res.status === 304) return setStatus('github', { ok: true });
    if (res.status === 401) return setStatus('github', { ok: false, text: 'GitHub rejected the token. Use a classic token with the notifications scope.' });
    if (res.status === 403 || res.status === 429) return setStatus('github', { ok: false, text: 'GitHub rate limit reached. Islet will try again later.' });
    if (!res.ok) return setStatus('github', { ok: false, text: `GitHub answered ${res.status}. Islet will try again.` });

    const list = await res.json();
    const first = !st.ghSeen;
    const seen = st.ghSeen || {};
    const fresh = list
      .filter((n) => n.unread && seen[n.id] !== n.updated_at)
      .filter((n) => cfg.filter === 'all' || IMPORTANT.has(n.reason))
      .sort((a, b) => Date.parse(b.updated_at) - Date.parse(a.updated_at));
    const nextSeen = {};
    list.forEach((n) => { nextSeen[n.id] = n.updated_at; });
    await chrome.storage.local.set({ ghSeen: nextSeen, ghLastModified: res.headers.get('Last-Modified') || '' });
    await setStatus('github', { ok: true, unread: list.length, text: '' });

    if (first) {
      if (list.length) {
        await deliver({ type: 'message', title: `${list.length} unread on GitHub`, body: "Connected. New ones will drop in as they arrive.", app: 'github', icon: 'github', url: 'https://github.com/notifications' });
      }
      return;
    }
    await announce(fresh.map(ghToNote), deliver, (rest) => ({ body: `New GitHub notifications`, app: 'github', icon: 'github', url: 'https://github.com/notifications' }));
  }

  async function pollGmail(deliver, opts) {
    opts = opts || {};
    const cfg = (await loadSources()).gmail;
    if (!cfg.enabled && !opts.force) return;
    const account = Math.max(0, Math.min(9, cfg.account | 0));
    const url = `https://mail.google.com/mail/u/${account}/feed/atom${cfg.label === 'important' ? '/%5Eiim' : ''}`;

    let res, text;
    try { res = await fetch(url, { credentials: 'include', cache: 'no-store' }); text = await res.text(); }
    catch (_) { return setStatus('gmail', { ok: false, text: "Couldn't reach Gmail. Islet will try again." }); }

    const feed = res.ok ? parseAtom(text) : null;
    if (!feed) return setStatus('gmail', { ok: false, text: 'Sign in to Gmail in this browser, then check again.' });

    const { gmSeen } = await chrome.storage.local.get({ gmSeen: null });
    const first = !gmSeen;
    const seen = new Set(gmSeen || []);
    const fresh = feed.entries.filter((e) => e.id && !seen.has(e.id));
    await chrome.storage.local.set({ gmSeen: feed.entries.map((e) => e.id).slice(0, 200) });
    await setStatus('gmail', { ok: true, unread: feed.count, text: '' });

    const inbox = `https://mail.google.com/mail/u/${account}/`;
    if (first) {
      if (feed.count) {
        await deliver({ type: 'message', title: `${feed.count} unread in Gmail`, body: 'Connected. New mail will drop in as it arrives.', app: 'gmail', icon: 'mail', url: inbox });
      }
      return;
    }
    await announce(fresh.map((e) => gmailToNote(e, account)), deliver, () => ({ body: 'New emails in Gmail', app: 'gmail', icon: 'mail', url: inbox }));
  }

  async function pollAll(deliver) {
    await Promise.allSettled([pollGitHub(deliver), pollGmail(deliver)]);
  }

  async function ensureAlarm() {
    const s = await loadSources();
    if (s.github.enabled || s.gmail.enabled) {
      const existing = await chrome.alarms.get('islet-poll');
      if (!existing || existing.periodInMinutes !== s.interval) {
        await chrome.alarms.create('islet-poll', { delayInMinutes: s.interval, periodInMinutes: s.interval });
      }
    } else {
      await chrome.alarms.clear('islet-poll');
    }
  }

  async function markRead(ref) {
    const id = String(ref || '').replace(/^gh:/, '');
    if (!/^\d+$/.test(id)) return false;
    const { ghToken } = await chrome.storage.local.get({ ghToken: '' });
    if (!ghToken) return false;
    try {
      const res = await fetch(`${GH_API}/notifications/threads/${id}`, {
        method: 'PATCH',
        headers: { Authorization: 'Bearer ' + ghToken, Accept: 'application/vnd.github+json', 'X-GitHub-Api-Version': '2022-11-28' },
      });
      return res.status === 205 || res.ok;
    } catch (_) { return false; }
  }

  const api = { DEFAULT_SOURCES, WEB, webToNote, loadSources, getStatus, setStatus, pollGitHub, pollGmail, pollAll, ensureAlarm, markRead, parseAtom, ghToNote, ghHtmlUrl, gmailToNote };
  g.IsletSources = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof self !== 'undefined' ? self : globalThis);
