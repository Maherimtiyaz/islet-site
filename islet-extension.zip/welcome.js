/* Islet welcome page: opens once, right after install. */
'use strict';

const REPO_URL = 'https://github.com/Maherimtiyaz/islet-site';

const C = window.IsletCore;
const $ = (id) => document.getElementById(id);
$('ver').textContent = 'v' + chrome.runtime.getManifest().version;
// Once Islet is on the Chrome Web Store, its listing lives at this extension's own id.
$('review').href = `https://chromewebstore.google.com/detail/${chrome.runtime.id}/reviews`;
$('star').href = REPO_URL;

// The real shortcut, as Chrome has it on this computer (Alt+Shift+I, or Option+Shift+I on a Mac).
const isMac = /Mac/i.test(navigator.platform || navigator.userAgent);
chrome.commands.getAll().then((cmds) => {
  const c = cmds.find((x) => x.name === '_execute_action');
  const keys = (c && c.shortcut) || (isMac ? '⌥⇧I' : 'Alt+Shift+I');
  document.querySelectorAll('.shortcut').forEach((el) => { el.textContent = keys; });
}).catch(() => {});

const NOTES = [
  { type: 'reminder', icon: 'github', title: 'Fix race in queue worker', body: 'Review requested · acme/web#482 (example)', app: 'github' },
  { type: 'message', icon: 'mail', title: 'Ana Silva', body: 'Q4 budget, final numbers (example)', app: 'gmail' },
  { type: 'message', icon: 'slack', title: 'Priya Raman', body: '#launch: staging is green (example)', app: 'slack' },
  { type: 'success', title: 'CI passed', body: 'main · 2m 14s · 148 tests (example)', app: 'github' },
];

// Create the island straight away with the default look, so the buttons work at once.
const island = C.create(Object.assign({}, C.DEFAULTS, { mode: 'fixed', top: 14 }));
// The first one stays until you dismiss it (click, then Dismiss, or swipe it up).
setTimeout(() => island.show({ type: 'success', title: 'Islet is installed', body: 'Hover to pause, click to open, swipe up to dismiss.', app: 'islet', sticky: true }), 400);

// Apply your saved look, if you've already picked one.
chrome.storage.sync.get({ islet: null }).then(({ islet }) => { if (islet) island.setOptions(islet); }).catch(() => {});

let i = 0;
$('again').addEventListener('click', () => { island.replace(NOTES[i]); i = (i + 1) % NOTES.length; });

// Open the Islet panel. Older Chrome versions can't open it from a page, so point at the icon instead.
$('open').addEventListener('click', async () => {
  const hint = $('open-hint');
  try {
    if (!chrome.action.openPopup) throw new Error('unsupported');
    await chrome.action.openPopup();
    hint.textContent = "The Islet panel opens from its icon in your toolbar, top right. If it didn't open, click that icon.";
  } catch (_) {
    hint.textContent = 'Click the Islet icon in your toolbar (top right, next to the address bar). Not there? Click the puzzle piece and pin Islet.';
  }
});
