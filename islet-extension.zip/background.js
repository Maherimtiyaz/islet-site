/* Islet service worker: delivers notes to the active tab, runs reminders and focus sessions. */
'use strict';

importScripts('sources.js');
const Sources = self.IsletSources;

const timeLabel = (ms) => new Date(ms).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });

async function getLocal(key, fallback) {
  const got = await chrome.storage.local.get({ [key]: fallback });
  return got[key];
}

function systemNotify(payload) {
  chrome.notifications.create('islet-' + Date.now(), {
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title: payload.title || 'Islet',
    message: payload.body || ' ',
    priority: 1,
  });
}

// Show a note at the top of the active tab. Falls back to a system
// notification on pages extensions can't touch (chrome://, Web Store)
// or when Chrome isn't the focused app.
async function deliver(payload) {
  let shown = false;
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (tab && tab.id != null) {
    const msg = { type: 'ISLET_SHOW', payload };
    try {
      await chrome.tabs.sendMessage(tab.id, msg);
      shown = true;
    } catch (_) {
      // Tab was open before the extension loaded: inject, then retry.
      try {
        await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['island-core.js', 'content.js'] });
        await chrome.tabs.sendMessage(tab.id, msg);
        shown = true;
      } catch (_) { /* restricted page */ }
    }
  }
  let focused = true;
  try { focused = (await chrome.windows.getLastFocused()).focused; } catch (_) {}
  if (!shown || !focused) systemNotify(payload);
  return shown ? 'island' : 'system';
}

async function schedule(minutes, payload) {
  const id = Math.random().toString(36).slice(2, 10);
  const when = Date.now() + minutes * 60000;
  const list = await getLocal('scheduled', {});
  list[id] = { when, payload };
  await chrome.storage.local.set({ scheduled: list });
  await chrome.alarms.create('islet:' + id, { when });
  return { id, when };
}

async function cancel(id) {
  const list = await getLocal('scheduled', {});
  delete list[id];
  await chrome.storage.local.set({ scheduled: list });
  await chrome.alarms.clear('islet:' + id);
}

async function startFocus(minutes) {
  const end = Date.now() + minutes * 60000;
  await chrome.storage.local.set({ focus: { end, minutes } });
  await chrome.alarms.create('islet:focus', { when: end });
  await deliver({
    type: 'timer',
    title: `Focus · ${minutes} min`,
    body: `Ends at ${timeLabel(end)}. I'll tap you when it's done.`,
    app: 'focus',
  });
  return { end };
}

async function stopFocus() {
  await chrome.storage.local.remove('focus');
  await chrome.alarms.clear('islet:focus');
}

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'islet-poll') { await Sources.pollAll(deliver); return; }
  if (!alarm.name.startsWith('islet:')) return;
  if (alarm.name === 'islet:focus') {
    const focus = await getLocal('focus', null);
    await chrome.storage.local.remove('focus');
    await deliver({
      type: 'success',
      title: 'Focus session complete',
      body: `${focus ? focus.minutes : 25} minutes of deep work. Stand up, stretch, then go again.`,
      app: 'focus',
      sticky: true,
    });
    return;
  }
  const id = alarm.name.slice('islet:'.length);
  const list = await getLocal('scheduled', {});
  const item = list[id];
  if (!item) return;
  delete list[id];
  await chrome.storage.local.set({ scheduled: list });
  await deliver(item.payload);
});

async function handle(msg, sender) {
  switch (msg && msg.type) {
    case 'ISLET_POP': return { via: await deliver(msg.payload) };
    case 'ISLET_SCHEDULE': return schedule(msg.minutes, msg.payload);
    case 'ISLET_CANCEL': await cancel(msg.id); return { ok: true };
    case 'ISLET_FOCUS_START': return startFocus(msg.minutes);
    case 'ISLET_FOCUS_STOP': await stopFocus(); return { ok: true };
    case 'ISLET_STATE': return { scheduled: await getLocal('scheduled', {}), focus: await getLocal('focus', null) };
    case 'ISLET_ACTION':
      if (msg.id === 'snooze' && msg.note) {
        await schedule(5, Object.assign({}, msg.note, { id: undefined, app: 'snoozed' }));
      }
      if (msg.id === 'markread' && msg.note && msg.note.ref) await Sources.markRead(msg.note.ref);
      if (msg.id === 'focus' && msg.note && /^web:\d+:/.test(msg.note.ref || '')) {
        const [, tabId, nid] = msg.note.ref.match(/^web:(\d+):(.*)$/);
        try {
          const tab = await chrome.tabs.update(Number(tabId), { active: true });
          await chrome.windows.update(tab.windowId, { focused: true });
          await chrome.tabs.sendMessage(Number(tabId), { type: 'ISLET_HOOK_CLICK', id: nid });
        } catch (_) { /* tab was closed */ }
      }
      return { ok: true };

    // ---- GitHub and Gmail ----
    case 'ISLET_SOURCES_GET': {
      const st = await chrome.storage.local.get({ ghToken: '' });
      return {
        sources: await Sources.loadSources(),
        status: await Sources.getStatus(),
        token: st.ghToken ? '…' + st.ghToken.slice(-4) : '',
      };
    }
    case 'ISLET_SOURCES_SET': {
      const before = await Sources.loadSources();
      const next = msg.sources;
      await chrome.storage.local.set({ sources: next });
      // Turning a source on, or pointing it somewhere new, starts fresh with one summary.
      const ghReset = next.github.enabled && (!before.github.enabled || before.github.filter !== next.github.filter);
      const gmReset = next.gmail.enabled && (!before.gmail.enabled || before.gmail.account !== next.gmail.account || before.gmail.label !== next.gmail.label);
      if (ghReset) await chrome.storage.local.set({ ghSeen: null, ghLastModified: '' });
      if (gmReset) await chrome.storage.local.set({ gmSeen: null });
      await Sources.ensureAlarm();
      if (ghReset) await Sources.pollGitHub(deliver);
      if (gmReset) await Sources.pollGmail(deliver);
      return { ok: true };
    }
    case 'ISLET_GH_TOKEN_SET': {
      const token = String(msg.token || '').trim();
      if (!/^[A-Za-z0-9_]{20,255}$/.test(token)) return { error: "That doesn't look like a GitHub token." };
      await chrome.storage.local.set({ ghToken: token, ghSeen: null, ghLastModified: '' });
      await Sources.pollGitHub(deliver);
      return { ok: true };
    }
    case 'ISLET_GH_TOKEN_CLEAR':
      await chrome.storage.local.remove(['ghToken', 'ghSeen', 'ghLastModified']);
      await Sources.setStatus('github', { ok: false, text: 'Add a token to start.', unread: 0 });
      return { ok: true };
    case 'ISLET_WEB_HELLO':
      return { ok: true };
    case 'ISLET_WEB_NOTE': {
      const cfg = (await Sources.loadSources())[msg.source];
      if (!cfg || !cfg.enabled || !sender.tab) return { ok: false };
      // Skip it if you're already looking at that tab.
      let looking = false;
      try { looking = sender.tab.active && (await chrome.windows.get(sender.tab.windowId)).focused; } catch (_) {}
      await Sources.setStatus(msg.source, { ok: true, lastAt: Date.now() });
      if (looking) return { ok: true, skipped: true };
      await deliver(Sources.webToNote(msg.source, msg, sender.tab.id, cfg));
      return { ok: true };
    }
    case 'ISLET_OPEN_WEB': {
      const w = Sources.WEB[msg.source];
      if (!w) return { ok: false };
      const [tab] = await chrome.tabs.query({ url: w.url });
      if (tab) { await chrome.tabs.update(tab.id, { active: true }); await chrome.windows.update(tab.windowId, { focused: true }); }
      else await chrome.tabs.create({ url: w.home, pinned: true });
      return { ok: true };
    }
    case 'ISLET_CHECK_NOW':
      if (msg.source === 'github') await Sources.pollGitHub(deliver, { force: true });
      if (msg.source === 'gmail') await Sources.pollGmail(deliver, { force: true });
      return { ok: true };
    default: return null;
  }
}

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  handle(msg, sender).then(reply, (e) => reply({ error: String(e) }));
  return true;
});

chrome.runtime.onInstalled.addListener(() => { Sources.ensureAlarm(); });
chrome.runtime.onStartup.addListener(() => { Sources.ensureAlarm(); });

// First install: open the welcome page once.
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') chrome.tabs.create({ url: chrome.runtime.getURL('welcome.html') });
});
